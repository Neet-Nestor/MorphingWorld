# Lycan // TODO some sort of logo when we think it's ready
The aim of this project is to share tools and helper code we use for our Haxe game development.

// TODO build status, examples, haxelib badge, games, documentation, migrating, donations etc...

## Usage
At present the codebase is unstable and totally unfinished. Don't use this for anything!