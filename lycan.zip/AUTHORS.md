# The Core Lycan Team

* [Sam Twidale](//github.com/Tw1ddle) - Co-Founder, Developer
* [Joe Williamson](//github.com/JoeCreates) - Co-Founder, Developer

### Special Thanks

// TODO get the link right
* For a list of those that contributed to the Lycan codebase, refer to the [GitHub list of contributors](https://github.com/Lycan/lycan/contributors)